-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 25 Mar 2018 la 19:42
-- Versiune server: 5.7.14
-- PHP Version: 5.6.25

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erp`
--

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `cadru_didactic`
--

CREATE TABLE `cadru_didactic` (
  `Id` int(11) NOT NULL,
  `Grad` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Nume` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Prenume` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Disciplina` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Id_grad_titular` int(11) NOT NULL,
  `Titlu` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Vechime` int(11) NOT NULL,
  `Titular_suplinitor` varchar(100) COLLATE utf8_romanian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_romanian_ci;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `diciplina`
--

CREATE TABLE `diciplina` (
  `Id` int(11) NOT NULL,
  `Nume` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Tip` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Specializare` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Nr_ore_total` int(11) NOT NULL,
  `Pregatire_individuala` int(11) NOT NULL,
  `Nr_pc` int(11) NOT NULL,
  `Limba` varchar(100) COLLATE utf8_romanian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_romanian_ci;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `facultate`
--

CREATE TABLE `facultate` (
  `Id` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Nume` varchar(100) COLLATE utf8_romanian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_romanian_ci;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `nota_comanda`
--

CREATE TABLE `nota_comanda` (
  `Id` int(11) NOT NULL,
  `Disciplina` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Facultate` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Id_forma` int(11) NOT NULL,
  `Id_plan_invatamant` int(11) NOT NULL,
  `Ciclu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_romanian_ci;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `plan_invatamant`
--

CREATE TABLE `plan_invatamant` (
  `Id` int(11) NOT NULL,
  `An_studiu` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Specializare` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Facultate` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Disciplina` varchar(100) COLLATE utf8_romanian_ci NOT NULL,
  `Total_ore` int(11) NOT NULL,
  `Nr_ore_pc` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_romanian_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cadru_didactic`
--
ALTER TABLE `cadru_didactic`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Disciplina` (`Disciplina`);

--
-- Indexes for table `diciplina`
--
ALTER TABLE `diciplina`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Nume` (`Nume`);

--
-- Indexes for table `facultate`
--
ALTER TABLE `facultate`
  ADD KEY `Nume` (`Nume`);

--
-- Indexes for table `nota_comanda`
--
ALTER TABLE `nota_comanda`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Facultate` (`Facultate`),
  ADD KEY `Disciplina` (`Disciplina`),
  ADD KEY `Id_plan_invatamant` (`Id_plan_invatamant`);

--
-- Indexes for table `plan_invatamant`
--
ALTER TABLE `plan_invatamant`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `Facultate` (`Facultate`),
  ADD KEY `Disciplina` (`Disciplina`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cadru_didactic`
--
ALTER TABLE `cadru_didactic`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `diciplina`
--
ALTER TABLE `diciplina`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `nota_comanda`
--
ALTER TABLE `nota_comanda`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `plan_invatamant`
--
ALTER TABLE `plan_invatamant`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Restrictii pentru tabele sterse
--

--
-- Restrictii pentru tabele `cadru_didactic`
--
ALTER TABLE `cadru_didactic`
  ADD CONSTRAINT `cadru_didactic_ibfk_1` FOREIGN KEY (`Disciplina`) REFERENCES `diciplina` (`Nume`);

--
-- Restrictii pentru tabele `nota_comanda`
--
ALTER TABLE `nota_comanda`
  ADD CONSTRAINT `nota_comanda_ibfk_1` FOREIGN KEY (`Disciplina`) REFERENCES `diciplina` (`Nume`),
  ADD CONSTRAINT `nota_comanda_ibfk_2` FOREIGN KEY (`Facultate`) REFERENCES `facultate` (`Nume`),
  ADD CONSTRAINT `nota_comanda_ibfk_3` FOREIGN KEY (`Id_plan_invatamant`) REFERENCES `plan_invatamant` (`Id`);

--
-- Restrictii pentru tabele `plan_invatamant`
--
ALTER TABLE `plan_invatamant`
  ADD CONSTRAINT `plan_invatamant_ibfk_1` FOREIGN KEY (`Facultate`) REFERENCES `facultate` (`Nume`),
  ADD CONSTRAINT `plan_invatamant_ibfk_2` FOREIGN KEY (`Disciplina`) REFERENCES `diciplina` (`Nume`);
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
